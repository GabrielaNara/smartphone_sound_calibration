Descrição do arquivo de exportação

 meta.properties Arquivo com informações sobre o dispositivo e a gravação:
 - version_name Versão maior, menor e revisão
 - build_date Data da montagem do APK
 - version_number Inteiro indicando a versão da aplicação
 - time_length Duração da gravação em segundos
 - uuid Identificador aleatório definido no primeiro início da aplicação
 - leq_mean Nível sonoro equivalente médio da medição em dB(A)
 - record_utc Data da gravação em milisegundos decorridos desde 01-01-1970
 - device_manufacturer device_model device_product Informações sobre o hardware do dispositivo
 - pleasantness Qualidade do som (desagradável-agradável) definida pelo usuário 1-100
 - tags Tags selecionadas pelo usuário (em inglês) separadas por vírgulas
 - user_profile Conhecimento do usuário em Acústica NONE, NOVICE, EXPERT
 - noiseparty_tag Identificador NoiseParty da gravação

 track.geojson Arquivo com amostras das medições, 1s. Formato geojson (http://geojson.io)
 - leq_mean Nível sonoro equivalente médio, 1s, em dB(A)
 - accuracy Precisão da localização em m (fornecida por GPS, rede ou GSM)
 - location_utc Data da definição da localização em milisegundos decorridos desde 01-01-1970
 - leq_utc Data da medição em milisegundos decorridos desde 01-01-1970
 - leq_id Identificador único da gravação
 - marker_color Cor usada por geojson.io
 - bearing Orientação do movimento. Veja https://developer.android.com/reference/android/location/Location.html#getBearing()
 - speed Velocidade estimada do dispositivo em m/s
 - leq_frequency Nível sonoro equivalente médio, 1s, em dB(A), para a frequência especificada
